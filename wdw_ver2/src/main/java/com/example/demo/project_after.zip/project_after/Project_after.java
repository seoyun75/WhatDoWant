package com.example.demo.project_after;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.di.Action;
import com.example.demo.model.Basic_infoVO;
import com.example.demo.model.Basic_reqVO;
import com.example.demo.model.Maker_infoVO;
import com.example.demo.model.MemberVO;
import com.example.demo.model.PurhistoryVO;
import com.example.demo.model.Reward_dsnVO;
import com.example.demo.model.RiskpolicyVO;
import com.example.demo.model.StoryVO;

// Bean생성, menu
@Service("project_after")
public class Project_after implements Action {

	@Resource
	Project_afterMapper mapper;

	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		String service = (String)map.get("service");
		
		// 회원의 프로젝트를 생성하고 작성하기 위해 세션에서 회원정보를 가져옴
		MemberVO mem = (MemberVO) req.getSession().getAttribute("member");
		int mem_code = mem.getMember_no();
		int pro_code = Integer.parseInt(req.getParameter("pro_code"));
			
		Object res = null;
		
		System.out.println("project_after 서비스클래스 실행() - "+ service+ ", "+ pro_code);
		// 서비스를 기준으로 다른 메소드를 동작시킴
		switch (service) {
		case "after_fundingStatus":
			
			break;
		case "after_sendManagement":
			System.out.println(pro_code);
			Map<String, Object> result= new HashMap<String, Object>();
			List<PurhistoryVO> pvoList = mapper.deliveryList(pro_code);
			System.out.println(2);
			
			
			for (PurhistoryVO pvo : pvoList) {
				if(pvo.getPurhistory_delivery()==null) {
					pvo.setDelivery_state("발송전");
				}else {
					pvo.setDelivery_state("발송완료");
				}
				System.out.println(pvo.getDelivery_state());
			}
			result.put("pvoList",pvoList);
			result.put("page", req.getParameter("page"));
			
			Date dd = new Date();
			
			System.out.println(result);
			return result;
		
		case "after_sendManagement_send": case "after_sendManagement_cancel":
			if(req.getParameterValues("send")!=null) {
				System.out.println(3);
				for (int i = 0; i < req.getParameterValues("send").length; i++) {
					Map<String, Object> id_date = new HashMap<String, Object>();
					String funding_date = req.getParameterValues("funding_date")[i].substring(0, 8);
					
					id_date.put("send", req.getParameterValues("send")[i]);
					id_date.put("funding_date", funding_date);
					
					if(service.equals("after_sendManagement_send")) {
						id_date.put("delivery", new Timestamp(new Date().getTime()));
					}else {
						id_date.put("delivery", null);
					}
					System.out.println(service+" : "+mapper.sendDelivery(id_date));						
				}
			}
			break;
		case "after_inquiry_answer":
			break;
		

			
		}
		
		return res;
		
	}
	
	
}
