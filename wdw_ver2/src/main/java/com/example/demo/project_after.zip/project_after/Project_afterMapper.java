package com.example.demo.project_after;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.example.demo.model.PurhistoryVO;

@Mapper
public interface Project_afterMapper {
	List<PurhistoryVO>deliveryList(Integer pro_code);
	int sendDelivery(Map<String, Object> id_date);
}
