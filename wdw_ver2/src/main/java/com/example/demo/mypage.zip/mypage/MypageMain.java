package com.example.demo.mypage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.connector.Response;
import org.springframework.stereotype.Service;

import com.example.demo.di.Action;
import com.example.demo.model.MemberVO;
import com.example.demo.model.ProjectVO;
import com.example.demo.model.ShoppingVO;


@Service("mypageMain")
public class MypageMain implements Action{
	/* 람다식으로 변경하기 */
	@Resource
	MypageMapper mapper; 
	
	
	@Override
	public Object execute(HashMap<String, Object> obj, HttpServletRequest req) {
		String service = (String) ((Map)obj).get("service");
		MemberVO mvo = (MemberVO) ((Map)obj).get("mvo");
		MemberVO user = (MemberVO)req.getSession().getAttribute("member");
		String id = user.getMember_id();
		System.out.println("main execute() - mvo: "+mvo+", user:"+user);
		

		switch (service) {
		case "main":
			Map<String , Object> all = new HashMap<>();
			List<ShoppingVO> shopping = mapper.shopHistory(id);
			List<ProjectVO> myProject = mapper.project(id);
			int income = 0;
			int use = 0;
			for (ProjectVO proj : myProject) {
				if(proj.getPro_target_amount()<proj.getPro_now_amount()&&proj.getPro_state().equals("종료")) {
					income+=proj.getPro_now_amount();
				}
			}
			for (ShoppingVO shopp : shopping) {
				if(shopp.getPurhistory_paystate().equals("결제완료")) {
					use+=shopp.getPurhistory_amount();
				}
			}
			
			all.put("actore", user(id));
			all.put("shopping", shopping);
			all.put("project", myProject);
			all.put("income", income);
			all.put("use", use);
//			return null;
			return all;
		 case "myInfo":
			System.out.println("Action 'infoModify'");
			mvo.setMember_id(id);
			System.out.println(req.getAttribute("pre_pw"));

			
			if(req.getMethod().equals("POST")) {
				mvo.setMember_pw(user.getMember_pw());
				infomodify(mvo, req);
			}
				
			return user(id);
		 case "withdraw":
			 if(req.getParameter("passward").equals(user.getMember_pw())) {
				mapper.deleteCard(user);
				mapper.deleteAccount(user);
			 	mapper.deleteUser(user);
			 	req.getSession().invalidate();
			 	
			 }
			 break;
		 default:
			break;
		}
		return null;
	}
	
	MemberVO user(String id) {
		return mapper.user(id);
	}
	

	
	String infomodify(MemberVO mvo,HttpServletRequest req) {
		String msg="";
		if(req.getParameter("prepw")!=null){
			System.out.println("비밀번호 변경"+req.getParameter("newpw"));
			if(req.getParameter("prepw").equals(mvo.getMember_pw())&&req.getParameter("newpw").equals(req.getParameter("chkpw")))
				mvo.setMember_pw(req.getParameter("newpw"));
				mapper.pwModify(mvo);
				System.out.println("pwModify 실행완료");
				msg="비밀번호가 변경되었습니다.";
		}else if(mvo.getMember_pname()!=null) {
			System.out.println("1번실행"+mvo);
			mvo.setMember_address(mvo.getMember_address()+"&"+req.getParameter("member_address_second"));
			System.out.println(mvo.getMember_address());
			mapper.infoModify(mvo);
			msg="정보가 변경되었습니다.";
		}
		System.out.println("완료1");
		req.getSession().setAttribute("member", mapper.user(mvo.getMember_id()));
		System.out.println("완료2");
		
		return msg;
	};

	
}
