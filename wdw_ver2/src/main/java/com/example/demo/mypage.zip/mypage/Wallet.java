package com.example.demo.mypage;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.example.demo.di.Action;
import com.example.demo.model.AccountVO;
import com.example.demo.model.MemberVO;
import com.example.demo.model.ProjectVO;
import com.example.demo.model.PurhistoryVO;

@Service("wallet")
public class Wallet implements Action {
	@Resource
	MypageMapper mapper;

	@Override
	public Object execute(HashMap<String, Object> map, HttpServletRequest req) {
		System.out.println("wallet execute()"+ map.get("service"));
		String service = ""+map.get("service");
		AccountVO account = (AccountVO)map.get("avo");
		MemberVO actore = (MemberVO)req.getSession().getAttribute("member");
		switch(service) {
		case "wallet":
			Map<String, Object> obj = moneyFlow(actore);
			List<AccountVO> list = mapper.accountList(actore.getMember_no());
			obj.put("account", list);
			
			return obj;
		case "account":
			if(req.getMethod().equals("POST")) {
				account.setAccount_member_no(actore.getMember_no());
				mapper.InsertAccount(account);
			}
			
			list = mapper.accountList(actore.getMember_no());
			System.out.println(list);
			return list;
		case "accountDelete":
			mapper.accountDelete(req.getParameter("account_number"));
			break;
		case "moneyFlow":

			return moneyFlow(actore);
		}
		
		return null;
	}
	
	Map<String, Object> moneyFlow(MemberVO actore){
		Map<String , Object> obj = new HashMap<>();
		List<PurhistoryVO> ps = mapper.useMoney(actore.getMember_id());
		List<ProjectVO> pj = mapper.incomeMoney(actore.getMember_id());
		int psTotal= 0;
		int pjTotal= 0;
		for (PurhistoryVO pvo : ps) {
			psTotal += pvo.getPurhistory_amount();
		}
		for (ProjectVO pvo : pj) {
			pjTotal += pvo.getPro_now_amount();
		}
		obj.put("buy", ps);
		obj.put("sell", pj);
		obj.put("buyTot", psTotal);
		obj.put("sellTot", pjTotal);
		
		return obj;
	}

}
